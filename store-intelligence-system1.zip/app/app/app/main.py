import sys
import os

# This looks at where main.py is, and adds all surrounding folders to Python's memory automatically!
current_dir = os.path.dirname(os.path.abspath(__file__))
sys.path.append(current_dir)
sys.path.append(os.path.dirname(current_dir))
sys.path.append(os.path.dirname(os.path.dirname(current_dir)))

import sys
import os

# This tells Python to automatically find your internal folders no matter what folder you start in!
sys.path.append(os.path.dirname(os.path.abspath(__file__)))

from models import StoreOverviewResponse, QueueMetricsResponse
from engine import StoreAnalyticsEngine
from fastapi import FastAPI, HTTPException, Query
from fastapi.middleware.cors import CORSMiddleware
from models import StoreOverviewResponse, QueueMetricsResponse
from engine import StoreAnalyticsEngine
import os

app = FastAPI(
    title="Purplle Store Intelligence Engine",
    description="Production-grade AI CCTV Analysis & POS Data Synchronization Platform",
    version="1.0.0"
)

# Enable CORS for frontend analytics dashboards
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# Relative data mapping declarations
BASE_DIR = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
POS_PATH = r"C:\store-intelligence-system\data\POS - sample transactionsb1e826f.csv"
EVENTS_PATH = r"C:\store-intelligence-system\data\sample_eventsbe42122.jsonl"



# Initialize engine instance
engine = StoreAnalyticsEngine(
    pos_csv_path=r"C:\store-intelligence-system\data\POS - sample transactions.csv",
    events_jsonl_path=r"C:\store-intelligence-system\data\sample_events.jsonl"
)
@app.get("/")
def read_root():
    return {"status": "healthy", "system": "Store Intelligence Engine Operational"}

@app.get("/api/v1/analytics/overview", response_model=StoreOverviewResponse)
def get_store_overview(store_id: str = Query(..., description="The unique Store Identification Code (e.g. ST1076)")):
    try:
        data = engine.calculate_store_overview(store_id=store_id)
        return data
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))

@app.get("/api/v1/analytics/queues", response_model=QueueMetricsResponse)
def get_queue_analytics(store_id: str = Query(..., description="The target Store Identification Code")):
    try:
        data = engine.get_queue_analytics(store_id=store_id)
        return data
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))

@app.get("/api/v1/analytics/zones")
def get_zone_density(store_id: str = Query(..., description="The target Store Identification Code")):
    try:
        data = engine.get_zone_heatmaps(store_id=store_id)
        return data
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))

if __name__ == "__main__":
    import uvicorn
    uvicorn.run("main:app", host="0.0.0.0", port=8000, reload=True)