import pandas as pd
import json
from datetime import datetime, timedelta
from typing import Dict, List, Any

class StoreAnalyticsEngine:
    def __init__(self, pos_csv_path: str, events_jsonl_path: str):
        self.pos_csv_path = pos_csv_path
        self.events_jsonl_path = events_jsonl_path
        self.df_pos = None
        self.raw_events = []
        self._load_datasets()

    def _load_datasets(self):
        # Load POS Data safely
        try:
            self.df_pos = pd.read_csv(self.pos_csv_path)
            
            # Dynamic store column matching to prevent 500 KeyErrors
            for col in self.df_pos.columns:
                if 'store' in col.lower():
                    self.df_pos.rename(columns={col: 'store_id'}, inplace=True)
                    break
                    
            # Create standard parsing column combining date and time
            self.df_pos['timestamp'] = pd.to_datetime(
                self.df_pos['order_date'] + ' ' + self.df_pos['order_time'], 
                format='%d-%m-%Y %H:%M:%S'
            )
        except Exception as e:
            print(f"Error loading POS CSV data: {e}")
            self.df_pos = pd.DataFrame()

        # Load Visual CV Streams from JSONL
        try:
            with open(self.events_jsonl_path, 'r') as f:
                for line in f:
                    if line.strip():
                        self.raw_events.append(json.loads(line))
        except Exception as e:
            print(f"Error loading event stream JSONL: {e}")

    def calculate_store_overview(self, store_id: str) -> Dict[str, Any]:
        """Calculates foundational high-level metrics for the store view."""
        # Clean store identifier format matching (e.g. ST1076 vs store_1076)
    def calculate_store_overview(self, store_id: str) -> Dict[str, Any]:
        """Calculates foundational high-level metrics for the store view."""
        # Convert input to both standard formats to be safe
        search_id_st = store_id.upper().strip()  # e.g., "ST1076"
        search_id_store = store_id.lower().replace("st", "store_").strip()  # e.g., "store_1076"

        # Filtering entries using case-insensitive checks
        # Fallback-safe filtering for entries and exits
        entries = []
        exits = []

        for e in self.raw_events:
            # Dynamically look for the event type key (could be 'event_type', 'type', or 'event')
            e_type = str(e.get("event_type") or e.get("type") or e.get("event") or "").lower().strip()
            
            # Dynamically look for the store code key (could be 'store_code', 'store', or 'store_id')
            e_store = str(e.get("store_code") or e.get("store") or e.get("store_id") or "").lower().strip()
            
            # Match identifiers
            is_store_match = e_store in [search_id_st.lower(), search_id_store.lower()] or search_id_st.lower() in e_store
            
            if is_store_match:
                if e_type == "entry":
                    entries.append(e)
                elif e_type == "exit":
                    exits.append(e)
        total_footfall = len(entries)
        staff_count = len([e for e in entries if e.get("is_staff") is True])

        # Processing Session Dwell Times
        dwell_times = []
        entry_map = {e["id_token"]: datetime.fromisoformat(e["event_timestamp"]) for e in entries if "id_token" in e}
        
        for ex in exits:
            token = ex.get("id_token")
            if token in entry_map:
                exit_ts = datetime.fromisoformat(ex["event_timestamp"])
                dwell = (exit_ts - entry_map[token]).total_seconds()
                dwell_times = [*dwell_times, dwell]

        avg_dwell = sum(dwell_times) / len(dwell_times) if dwell_times else 0.0

        # Extract Transactions for cross referencing conversion rates safely
        # Convert the dataframe store column to uppercase strings to guarantee a clean match
        self.df_pos['store_id_clean'] = self.df_pos['store_id'].astype(str).str.upper().str.strip()
        store_transactions = self.df_pos[self.df_pos['store_id_clean'] == search_id_st]
        unique_orders = store_transactions['order_id'].nunique()

        # Conversion computation (Orders / Non-staff entries)
        customer_footfall = total_footfall - staff_count
        conversion_rate = (unique_orders / customer_footfall * 100) if customer_footfall > 0 else 0.0

        return {
            "store_id": search_id_st,
            "total_footfall": total_footfall,
            "average_dwell_time_seconds": round(avg_dwell, 2),
            "conversion_rate": round(conversion_rate, 2),
            "staff_count": staff_count
        }
        # Filtering entries
        entries = [e for e in self.raw_events if e.get("event_type") == "entry" and e.get("store_code") == clean_id]
        exits = [e for e in self.raw_events if e.get("event_type") == "exit" and e.get("store_code") == clean_id]
        
        total_footfall = len(entries)
        staff_count = len([e for e in entries if e.get("is_staff") is True])

        # Processing Session Dwell Times
        dwell_times = []
        entry_map = {e["id_token"]: datetime.fromisoformat(e["event_timestamp"]) for e in entries if "id_token" in e}
        
        for ex in exits:
            token = ex.get("id_token")
            if token in entry_map:
                exit_ts = datetime.fromisoformat(ex["event_timestamp"])
                dwell = (exit_ts - entry_map[token]).total_seconds()
                dwell_times = [*dwell_times, dwell]

        avg_dwell = sum(dwell_times) / len(dwell_times) if dwell_times else 0.0

        # Extract Transactions for cross referencing conversion rates
        store_transactions = self.df_pos[self.df_pos['store_id'] == alt_clean_id]
        unique_orders = store_transactions['order_id'].nunique()

        # Conversion computation (Orders / Non-staff entries)
        customer_footfall = total_footfall - staff_count
        conversion_rate = (unique_orders / customer_footfall * 100) if customer_footfall > 0 else 0.0

        return {
            "store_id": alt_clean_id,
            "total_footfall": total_footfall,
            "average_dwell_time_seconds": round(avg_dwell, 2),
            "conversion_rate": round(conversion_rate, 2),
            "staff_count": staff_count
        }

    def get_queue_analytics(self, store_id: str) -> Dict[str, Any]:
        """Tracks operational performance metrics across custom-built checkout zones."""
        alt_clean_id = store_id.upper() if store_id.startswith("ST") else f"ST{store_id.replace('store_', '')}"
        
        q_events = [
            e for e in self.raw_events 
            if e.get("event_type") in ["queue_completed", "queue_abandoned"] and e.get("store_id") == alt_clean_id
        ]

        if not q_events:
            return {"average_wait_time": 0.0, "total_abandonments": 0, "abandonment_rate": 0.0, "peak_wait_time": 0}

        waits = [e["wait_seconds"] for e in q_events if "wait_seconds" in e]
        abandonments = len([e for e in q_events if e.get("abandoned") is True])
        
        avg_wait = sum(waits) / len(waits) if waits else 0.0
        peak_wait = max(waits) if waits else 0
        abandon_rate = (abandonments / len(q_events) * 100) if q_events else 0.0

        return {
            "average_wait_time": round(avg_wait, 2),
            "total_abandonments": abandonments,
            "abandonment_rate": round(abandon_rate, 2),
            "peak_wait_time": peak_wait
        }

    def get_zone_heatmaps(self, store_id: str) -> List[Dict[str, Any]]:
        """Maps absolute hotspots and tracking densities per spatial layout category."""
        alt_clean_id = store_id.upper() if store_id.startswith("ST") else f"ST{store_id.replace('store_', '')}"
        
        zones = [e for e in self.raw_events if e.get("event_type") == "zone_entered" and e.get("store_id") == alt_clean_id]
        
        zone_metrics = {}
        for z in zones:
            z_id = z["zone_id"]
            if z_id not in zone_metrics:
                zone_metrics[z_id] = {
                    "zone_name": z["zone_name"],
                    "zone_type": z["zone_type"],
                    "visitor_count": 0,
                    "coordinates": []
                }
            zone_metrics[z_id]["visitor_count"] += 1
            zone_metrics[z_id]["coordinates"].append({
                "x": z.get("zone_hotspot_x"), 
                "y": z.get("zone_hotspot_y")
            })
            
        return list(zone_metrics.values())