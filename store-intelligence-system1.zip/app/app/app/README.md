# AI-Powered Store Intelligence System 🏪📊

An advanced event-streaming and data analytics processing architecture designed to reconcile computer vision telemetry (CCTV) records with Point-of-Sale transaction logs to track conversions, bottlenecks, and footfalls.

---

## 🚀 Key Architectural Decisions

### 1. Data Reconciliation & Sliding Windows
- **Challenge:** POS transactions use standard timestamp objects (`hh:mm:ss`), whereas raw CV feeds log entries down to millisecond-level precision strings.
- **Solution:** Our analytic layer aggregates transactions to unified localized windows, mapping total conversion paths by tracking historical purchases within transactional bounds matching visitor exit patterns.

### 2. Stream Ingestion Pipeline Strategy
- To handle multiple production cameras logging hundreds of events per minute, we decoupled processing through memory-isolated Python dictionary structures mimicking high-performance time-series structures (`ClickHouse` / `DuckDB`).

---

## 🛠️ Execution Quickstart

1. **Install requirements:**
   ```bash
   pip install -r requirements.txt