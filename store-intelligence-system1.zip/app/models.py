from pydantic import BaseModel, Field
from typing import Optional, List
from datetime import datetime

class BaseStoreEvent(BaseModel):
    event_type: str
    store_id: str = Field(alias="store_code")
    camera_id: str
    event_timestamp: datetime

    class Config:
        populate_by_name = True

class EntryExitEvent(BaseStoreEvent):
    id_token: str
    is_staff: bool
    gender_pred: str
    age_pred: int
    age_bucket: str
    is_face_hidden: bool
    group_id: Optional[str] = None
    group_size: Optional[int] = None

class ZoneEvent(BaseModel):
    event_type: str
    track_id: int
    store_id: str
    camera_id: str
    zone_id: str
    zone_name: str
    zone_type: str
    is_revenue_zone: str
    event_time: datetime
    zone_hotspot_x: float
    zone_hotspot_y: float
    gender: str
    age: int
    age_bucket: str

class QueueEvent(BaseModel):
    queue_event_id: str
    event_type: str
    track_id: int
    store_id: str
    camera_id: str
    zone_id: str
    zone_name: str
    zone_type: str
    is_revenue_zone: str
    queue_join_ts: datetime
    queue_served_ts: Optional[datetime] = None
    queue_exit_ts: datetime
    wait_seconds: int
    queue_position_at_join: int
    abandoned: bool
    zone_hotspot_x: float
    zone_hotspot_y: float
    gender: str
    age: int
    age_bucket: str

# API Dashboard Output DTOs
class StoreOverviewResponse(BaseModel):
    store_id: str
    total_footfall: int
    average_dwell_time_seconds: float
    conversion_rate: float
    staff_count: int

class QueueMetricsResponse(BaseModel):
    average_wait_time: float
    total_abandonments: int
    abandonment_rate: float
    peak_wait_time: int